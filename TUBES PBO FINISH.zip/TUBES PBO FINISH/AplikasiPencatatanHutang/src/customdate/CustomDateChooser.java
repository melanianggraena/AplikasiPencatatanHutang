/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package customdate;

import com.toedter.calendar.JDateChooser;
import java.util.Date;
import java.text.SimpleDateFormat;

public class CustomDateChooser extends JDateChooser {
    public CustomDateChooser() {
        super();
        this.setDateFormatString("yyyy-MM-dd"); // Atur format tanggal
        this.setDate(new Date()); // Default ke hari ini
    }

    public String getSelectedDateAsString() {
        Date date = this.getDate();
        if (date != null) {
            return new SimpleDateFormat("yyyy-MM-dd").format(date);
        }
        return null;
    }

    public boolean isDateSelected() {
        return this.getDate() != null;
    }
}
