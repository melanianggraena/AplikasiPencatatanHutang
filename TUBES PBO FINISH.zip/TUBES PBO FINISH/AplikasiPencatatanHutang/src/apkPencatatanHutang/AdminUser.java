/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


// Implementasi Interface Loginable 

package apkPencatatanHutang;

/**
 *
 * @author melani
 */
public class AdminUser implements Loginable {
    private String defaultUsername;
    private String defaultPassword;

    public AdminUser(String username, String password) {
        this.defaultUsername = username;
        this.defaultPassword = password;
    }

    @Override
    public boolean validate(String inputUsername, String inputPassword) {
        return defaultUsername.equals(inputUsername) && defaultPassword.equals(inputPassword);
    }
    
    
}