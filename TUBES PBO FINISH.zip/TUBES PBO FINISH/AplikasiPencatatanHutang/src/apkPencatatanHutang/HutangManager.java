/*
 * Kelas `HutangManager` adalah kelas abstrak (abstract class) 
 * yang digunakan sebagai kelas induk (parent class) untuk mengatur logika umum
 * terkait manajemen hutang (masuk atau keluar).
 * Ini adalah penerapan OOP melalui inheritance (pewarisan) dan abstraction (abstraksi).
 */
package apkPencatatanHutang; // Mendeklarasikan paket aplikasi

import java.sql.Connection; // Mengimpor kelas untuk koneksi ke database
import javax.swing.table.DefaultTableModel; // Mengimpor kelas untuk manipulasi model tabel

// Deklarasi kelas abstrak (penerapan OOP: abstraction)
public abstract class HutangManager {

    // Variabel protected untuk koneksi database
    // Aksesibilitas protected memungkinkan kelas turunan mengaksesnya secara langsung.
    protected Connection connection;

    // Konstruktor kelas induk
    public HutangManager() {
        // Mendapatkan koneksi database melalui kelas DBConnection (komposisi dengan kelas Koneksi)
        connection = Koneksi.DBConnection.getConnection();
    }

    /*
     * Deklarasi metode abstrak (penerapan OOP: polymorphism).
     * `getTableModel` akan diimplementasikan oleh kelas turunan untuk 
     * menyediakan model tabel khusus (HutangMasuk atau HutangKeluar).
     */
    public abstract DefaultTableModel getTableModel();

    /*
     * Metode abstrak `saveData` untuk menyimpan data ke database.
     * Implementasi detail akan dilakukan oleh kelas turunan (penerapan OOP: polymorphism).
     * Parameter: 
     * - `data` adalah array string yang berisi data yang akan disimpan.
     */
    public abstract void saveData(String[] data);

    /*
     * Metode abstrak `deleteData` untuk menghapus data dari database.
     * Implementasi detail akan dilakukan oleh kelas turunan (penerapan OOP: polymorphism).
     * Parameter:
     * - `identifier` adalah string yang digunakan sebagai kunci untuk menghapus data.
     */
    public abstract void deleteData(String identifier);
}
