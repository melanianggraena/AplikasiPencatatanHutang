/*
 * Kelas `HutangKeluarManager` adalah turunan (subclass) dari `HutangManager`.
 * Kelas ini mengimplementasikan logika spesifik untuk mengelola data hutang keluar.
 * Penerapan OOP di sini mencakup inheritance (pewarisan) dan polymorphism.
 */

package apkPencatatanHutang; // Mendeklarasikan paket aplikasi

// Mengimpor kelas yang dibutuhkan
import java.sql.PreparedStatement; // Untuk eksekusi query dengan parameter
import java.sql.ResultSet; // Untuk membaca hasil query
import java.sql.SQLException; // Untuk menangani kesalahan SQL
import java.sql.Statement; // Untuk eksekusi query SQL
import javax.swing.JOptionPane; // Untuk menampilkan dialog
import javax.swing.table.DefaultTableModel; // Untuk manipulasi model tabel

// Deklarasi kelas turunan yang mewarisi `HutangManager`
public class HutangKeluarManager extends HutangManager {

    // Mengimplementasikan metode abstrak `getTableModel` dari `HutangManager`
    @Override
    public DefaultTableModel getTableModel() {
        // Membuat model tabel untuk data hutang keluar
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Pemberi Hutang"); // Kolom pertama
        tbl.addColumn("Jumlah Hutang"); // Kolom kedua
        tbl.addColumn("Tgl Pinjam"); // Kolom ketiga
        tbl.addColumn("Tgl Jatuh Tempo"); // Kolom keempat

        try {
            // Membuat pernyataan SQL untuk mengambil data hutang keluar
            Statement statement = connection.createStatement();
            ResultSet res = statement.executeQuery("SELECT * FROM HutangKeluar");
            
            // Iterasi hasil query untuk menambahkan baris ke tabel
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("pemberiHutang"), // Data pemberi hutang
                    res.getString("jumlahHutangHK"), // Data jumlah hutang
                    res.getString("tglPinjamHK"), // Data tanggal pinjam
                    res.getString("tglJatuhTempoHK") // Data tanggal jatuh tempo
                });
            }
        } catch (SQLException e) {
            // Menampilkan pesan jika terjadi kesalahan
            JOptionPane.showMessageDialog(null, "Gagal memuat data HutangKeluar: " + e.getMessage());
        }

        return tbl; // Mengembalikan model tabel
    }

    // Mengimplementasikan metode abstrak `saveData` untuk menyimpan data hutang keluar
    @Override
    public void saveData(String[] data) {
        try {
            // Query SQL untuk menyimpan data hutang keluar menggunakan parameter
            String query = "INSERT INTO HutangKeluar (pemberiHutang, jumlahHutangHK, tglPinjamHK, tglJatuhTempoHK) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            
            // Mengisi parameter query dengan data dari array
            for (int i = 0; i < data.length; i++) {
                ps.setString(i + 1, data[i]);
            }
            
            ps.executeUpdate(); // Menjalankan query
            JOptionPane.showMessageDialog(null, "Data HutangKeluar berhasil disimpan");
        } catch (SQLException e) {
            // Menampilkan pesan jika terjadi kesalahan
            JOptionPane.showMessageDialog(null, "Gagal menyimpan data HutangKeluar: " + e.getMessage());
        }
    }

    // Mengimplementasikan metode abstrak `deleteData` untuk menghapus data hutang keluar
    @Override
    public void deleteData(String identifier) {
        try {
            // Query SQL untuk menghapus data berdasarkan pemberi hutang
            String query = "DELETE FROM HutangKeluar WHERE pemberiHutang = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            
            ps.setString(1, identifier); // Mengisi parameter query
            ps.executeUpdate(); // Menjalankan query
            
            JOptionPane.showMessageDialog(null, "Data HutangKeluar berhasil dihapus");
        } catch (SQLException e) {
            // Menampilkan pesan jika terjadi kesalahan
            JOptionPane.showMessageDialog(null, "Gagal menghapus data HutangKeluar: " + e.getMessage());
        }
    }
}
