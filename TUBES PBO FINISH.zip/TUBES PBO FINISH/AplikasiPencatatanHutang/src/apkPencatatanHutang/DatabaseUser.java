/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apkPencatatanHutang;

import Koneksi.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author melani
 */
public class DatabaseUser implements Loginable{

    @Override
    public boolean validate(String inputUsername, String inputPassword) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT kataSandi FROM Pengguna WHERE namaPengguna = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, inputUsername);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("kataSandi");
                return storedPassword.equals(inputPassword); // *Jika tanpa hashing*
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
     
}
