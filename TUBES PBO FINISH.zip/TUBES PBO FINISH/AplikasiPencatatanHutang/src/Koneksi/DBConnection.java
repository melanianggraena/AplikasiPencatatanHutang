/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Koneksi;

/**
 *
 * @author melani
 */

import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
 

public class DBConnection {
    
    static Connection Koneksi;
    public static Connection getConnection(){
        try {
            Koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/PencatatanHutang","root","melani123");
            
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Koneksi database gagal");
        }
        return Koneksi;
    }
    
//    private static final String url =  "jdbc:mysql://localhost:3306/PencatatanHutang";
//    private static final String username = "root";
//    private static final String password = "melani123";
//    
//    
//    public static Connection getConnection() throws SQLException {
//        return DriverManager.getConnection(url, username, password);
//    }
//
//    // Method untuk mengeksekusi query dan mengembalikan ResultSet
//    public static ResultSet executeQuery(String query) throws SQLException {
//        Connection conn = getConnection();  // Mendapatkan koneksi database
//        PreparedStatement statement = conn.prepareStatement(query); // Siapkan query
//        return statement.executeQuery(); // Eksekusi dan kembalikan ResultSet
//    }
//    
//    // Method untuk mengeksekusi update (insert, update, delete)
//    public static int executeUpdate(String query) throws SQLException {
//        Connection conn = getConnection();  // Mendapatkan koneksi database
//        PreparedStatement statement = conn.prepareStatement(query); // Siapkan query
//        return statement.executeUpdate(); // Eksekusi dan kembalikan jumlah baris yang terpengaruh
//    }
    
}
